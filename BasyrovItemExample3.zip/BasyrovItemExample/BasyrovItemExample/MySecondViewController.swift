//
//  MySecondViewController.swift
//  BasyrovItemExample
//
//  Created by student on 22.02.2021.
//

import UIKit

class MySecondViewController: UIViewController, ObserverProtocol {
    func react(myIndex: Int?) -> String {
        <#code#>
    }
    

    var delegate : ObserverProtocol?
    var myIndex : Int?
    
    @IBOutlet weak var testCaption: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        
        testCaption.text = delegate?.react(myIndex: myIndex)
    }
    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let vc = segue.destination as? MySecondViewController {
            if segue.identifier == "edit" {
                print("Edit")
                vc.delegate = self
                vc.myIndex = self.myIndex
            }
            
            if (segue.identifier == "add") {
                print("add")
                vc.delegate = self
            }
        }
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
