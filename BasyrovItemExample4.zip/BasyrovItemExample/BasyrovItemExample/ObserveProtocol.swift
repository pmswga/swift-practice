//
//  ObserveProtocol.swift
//  BasyrovItemExample
//
//  Created by student on 22.02.2021.
//

import Foundation


protocol ObserverProtocol {
    
    func react(myIndex : Int?) -> String
    
}

