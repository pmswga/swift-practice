//
//  MySecondViewController.swift
//  BasyrovItemExample
//
//  Created by student on 22.02.2021.
//

import UIKit

class MySecondViewController: UIViewController {

    var delegate : ObserverProtocol?
    var myIndex : Int?
    
    @IBOutlet weak var testCaption: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        
        testCaption.text = delegate?.react(myIndex: myIndex)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
