//
//  ViewController.swift
//  BasyrovItemExample
//
//  Created by student on 22.02.2021.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource,  ObserverProtocol  {
    
    
    func react(myIndex: Int?) -> String {
        return myData[myIndex!]
    }
    
    var myData = [String]()
    var currentElement : Int?
    
    @IBOutlet weak var MyTable: UITableView!
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "id")
        
        cell?.textLabel?.text = myData[indexPath.row]
        
        return cell!
    }
    
    func initData() {
        for i in 0...9 {
            myData.append("Item \(i+1)")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initData()
    }

    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let vc = segue.destination as? MySecondViewController {
            if segue.identifier == "edit" {
                print("Edit")
                vc.delegate = self
                vc.myIndex = self.myIndex!
            }
            
            if (segue.identifier == "add") {
                print("add")
                vc.delegate = self
            }
        }
        
        
    }
    

}

